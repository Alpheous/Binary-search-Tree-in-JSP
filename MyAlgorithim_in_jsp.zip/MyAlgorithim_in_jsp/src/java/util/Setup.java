package util;

public class Setup {
	  public static final String DB_URL = "jdbc:mysql://localhost:3306/library";
	  public static final String DB_USERNAME = "root";
	  public static final String DB_PASSWORD = "";
	  public static final String MAIL_USERNAME = "mbusok.vee@gmail.com"; // like example@outlook.com
	  public static final String MAIL_PASSWORD = "password here";  // your mail password here
	  public static final String MAIL_SMTP_HOST = "smtp password here"; // smtp.live.com
	  public static final String MAIL_REGISTRATION_SITE_LINK = "http://localhost:8080/demos/VerifyRegisteredEmailHash";
}

