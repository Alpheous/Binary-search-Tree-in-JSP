/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sarath_sivan
 */
public class ReadFile {

    public static List<Customer> readFile(String fileName) throws FileNotFoundException, IOException { // reading each line from the customer.txt file, formatting it and returning a as a list for displaying in in our jsp page.
        FileInputStream fileInputStream = new FileInputStream(fileName);
        DataInputStream dataInputStream = new DataInputStream(fileInputStream);
        InputStreamReader inputStreamReader = new InputStreamReader(dataInputStream);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        List<Customer> customerList = new ArrayList<Customer>(); String readLine;

        while((readLine=bufferedReader.readLine())!=null) {
            System.out.println(readLine);
            customerList.add(formatReadLine(readLine));
        }

        dataInputStream.close();
        return customerList;
    }

    public static Customer formatReadLine(String readLine) {
        String[] splits = split(readLine);
        Customer customer = new Customer();
        customer.setKey(getTableDataFormat(splits[0]));
        customer.setId(getTableDataFormat(splits[1]));
        customer.setName(getTableDataFormat(splits[2]));
        customer.setSurname(getTableDataFormat(splits[3]));
        customer.setEmail(getTableDataFormat(splits[4]));
        customer.setMobile(getTableDataFormat(splits[5]));
        
        return customer;
    }

    public static String[] split(String readLine) { // splitting each line from the customer.txt file with "," as the delimiter
        return readLine.split(",");
    }

    public static String getTableDataFormat(String splits) { // Method for appending <td> tags with the formatted data
        StringBuilder tableData = new StringBuilder();
        tableData.append("<td>");
        tableData.append(splits);
        tableData.append("</td>");
        return tableData.toString();
    }

}
