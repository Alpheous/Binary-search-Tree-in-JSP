/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me;

/**
 *
 * @author njabulos
 */
public class Node{
    int key;
    String name;
    String surname;
    String email;
    String mobile;
    String id;
    
   public Node leftChild;
   public Node rightChild;
    
    Node(int key,String id, String name,String surname,String email,String mobile){
        this.key = key;
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.email =email;
        this.mobile =mobile;
        
    }
    
    
    
    @Override
    public String toString(){
        return "ID number is "+id+" belongs to "+name +" "+ surname+" with email address "+email+" phone number is "+mobile+" and has a key "+key;
    }
    

}